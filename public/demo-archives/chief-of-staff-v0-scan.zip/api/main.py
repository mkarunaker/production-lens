"""FastAPI application.

Single /brief endpoint that triggers the LangGraph orchestrator
and returns the morning brief as JSON.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone

from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from agents.orchestrator import run_morning_brief

logger = logging.getLogger(__name__)

app = FastAPI(
    title="Chief of Staff Agent API",
    description="Morning brief generation for leaders",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
async def health():
    return {"status": "ok"}


@app.get("/brief")
async def get_brief():
    """Generate and return a morning brief.

    Returns:
        JSON with morning_brief text, alignment_flag, routing_log, and metadata.
    """
    try:
        result = run_morning_brief()
    except Exception as exc:
        logger.exception("Morning brief generation failed")
        return JSONResponse(
            status_code=500,
            content={
                "error": f"Failed to generate morning brief: {exc}",
                "timestamp": datetime.now(timezone.utc).isoformat(),
            },
        )

    return {
        "morning_brief": result.get("morning_brief", "No brief generated"),
        "alignment_flag": result.get("alignment_flag", "Unknown"),
        "calendar_events": result.get("calendar_events", ""),
        "action_items": result.get("action_items", ""),
        "goals_summary": (
            result.get("goals_doc_content", "")[:500]
            if result.get("goals_doc_content")
            else ""
        ),
        "routing_log": result.get("routing_log", []),
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


frontend_path = Path(__file__).resolve().parent.parent / "frontend"
app.mount("/", StaticFiles(directory=str(frontend_path), html=True), name="frontend")
