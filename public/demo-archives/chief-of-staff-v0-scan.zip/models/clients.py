"""Model client initialization.

Initializes all four model clients from env credentials.
Gracefully degrades if a key is missing — logs a warning and skips that tier.
Never crashes on missing credentials.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

from config.settings import settings

logger = logging.getLogger(__name__)


# ── Model descriptors ─────────────────────────────────────────────────

@dataclass
class ModelClient:
    id: str
    display_name: str
    provider: str
    client: Any
    model_name: str


_AVAILABLE: dict[str, ModelClient] = {}


# ── Client initializers ───────────────────────────────────────────────

def _init_zenmux() -> ModelClient | None:
    if not settings.zenmux_api_key:
        logger.warning("ZENMUX_API_KEY not set — skipping GLM-5.2-free tier")
        return None
    try:
        from langchain_openai import ChatOpenAI

        client = ChatOpenAI(
            model="z-ai/glm-5.2-free",
            api_key=settings.zenmux_api_key,
            base_url=settings.zenmux_base_url,
        )
        return ModelClient(
            id="glm-5.2-free",
            display_name="GLM-5.2 Free",
            provider="zenmux",
            client=client,
            model_name="z-ai/glm-5.2-free",
        )
    except Exception as exc:
        logger.warning("Failed to initialize GLM-5.2-free client: %s", exc)
        return None


def _init_gpt4_mini() -> ModelClient | None:
    if not settings.openai_api_key:
        logger.warning("OPENAI_API_KEY not set — skipping GPT-4.1 Mini tier")
        return None
    try:
        from langchain_openai import ChatOpenAI

        client = ChatOpenAI(
            model="gpt-4.1-mini",
            api_key=settings.openai_api_key,
        )
        return ModelClient(
            id="gpt-4.1-mini",
            display_name="GPT-4.1 Mini",
            provider="openai",
            client=client,
            model_name="gpt-4.1-mini",
        )
    except Exception as exc:
        logger.warning("Failed to initialize GPT-4.1 Mini client: %s", exc)
        return None


def _init_claude_haiku() -> ModelClient | None:
    if not settings.anthropic_api_key:
        logger.warning("ANTHROPIC_API_KEY not set — skipping Claude Haiku 4.5 tier")
        return None
    try:
        from langchain_anthropic import ChatAnthropic

        client = ChatAnthropic(
            model="claude-haiku-4-5-20251001",
            api_key=settings.anthropic_api_key,
        )
        return ModelClient(
            id="claude-haiku-4-5-20251001",
            display_name="Claude Haiku 4.5",
            provider="anthropic",
            client=client,
            model_name="claude-haiku-4-5-20251001",
        )
    except Exception as exc:
        logger.warning("Failed to initialize Claude Haiku 4.5 client: %s", exc)
        return None


def _init_claude_sonnet() -> ModelClient | None:
    if not settings.anthropic_api_key:
        return None  # already warned in haiku init
    try:
        from langchain_anthropic import ChatAnthropic

        client = ChatAnthropic(
            model="claude-sonnet-4-6",
            api_key=settings.anthropic_api_key,
        )
        return ModelClient(
            id="claude-sonnet-4-6",
            display_name="Claude Sonnet 4.6",
            provider="anthropic",
            client=client,
            model_name="claude-sonnet-4-6",
        )
    except Exception as exc:
        logger.warning("Failed to initialize Claude Sonnet 4.6 client: %s", exc)
        return None


# ── Registry initialization ───────────────────────────────────────────

def init_clients() -> dict[str, ModelClient]:
    """Initialize all model clients. Returns dict of model_id -> ModelClient.

    Only models whose API keys are present and whose clients
    initialize successfully are included. Never raises.
    """
    registry: dict[str, ModelClient] = {}

    for init_fn in [
        _init_zenmux,
        _init_gpt4_mini,
        _init_claude_haiku,
        _init_claude_sonnet,
    ]:
        mc = init_fn()
        if mc is not None:
            registry[mc.id] = mc

    if not registry:
        logger.error(
            "No model clients could be initialized. "
            "Set at least one of ZENMUX_API_KEY, OPENAI_API_KEY, "
            "or ANTHROPIC_API_KEY in your .env file."
        )

    return registry


def get_client(model_id: str) -> ModelClient:
    """Get a client by model ID. Raises KeyError if not available."""
    if model_id not in _AVAILABLE:
        raise KeyError(
            f"Model '{model_id}' is not available. "
            f"Available models: {list(_AVAILABLE)}"
        )
    return _AVAILABLE[model_id]


def available_models() -> list[str]:
    """Return list of available model IDs."""
    return list(_AVAILABLE)


# Populate registry at import time
_AVAILABLE.update(init_clients())
