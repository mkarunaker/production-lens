"""Router configuration.

Scoring dimensions, thresholds, tier-to-model mappings,
and escalation rules for the Router Agent.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal


# ── Scoring dimensions ─────────────────────────────────────────────────

SCORE_DIMENSIONS = {
    "data_sources": {
        "description": "Number of data sources to cross-reference",
        1: "One source (single fetch)",
        2: "Two sources (cross-reference)",
        3: "Three or more sources (multi-source synthesis)",
    },
    "reasoning_type": {
        "description": "Type of reasoning required",
        1: "Extraction / formatting / parsing",
        2: "Summarization / single-source analysis",
        3: "Judgment / nuance / pattern detection",
    },
    "output_audience": {
        "description": "Who or what the output is for",
        1: "Another agent (structured intermediate)",
        2: "Structured data / JSON",
        3: "Human-facing final output",
    },
    "token_volume": {
        "description": "Estimated token volume for the task",
        1: "Under 2K tokens",
        2: "2K–10K tokens",
        3: "Over 10K tokens",
    },
    "confidence": {
        "description": "Confidence of the previous step or available context",
        1: "High confidence — well-defined task, complete context",
        2: "Moderate confidence — some ambiguity or missing context",
        3: "Low confidence — ambiguous, uncertain, or needs escalation",
    },
}


# ── Tier thresholds (total score ranges) ─────────────────────────────--

TIER_THRESHOLDS: list[tuple[tuple[int, int], str]] = [
    ((5, 7), "glm-5.2-free"),
    ((8, 10), "gpt-4.1-mini"),
    ((11, 13), "claude-haiku-4-5-20251001"),
    ((14, 15), "claude-sonnet-4-6"),
]


def resolve_tier(total_score: int) -> str:
    """Return the model ID for the given total score.

    Scores outside the valid range are clamped to the nearest tier.
    """
    for (lo, hi), model_id in TIER_THRESHOLDS:
        if lo <= total_score <= hi:
            return model_id
    if total_score < 5:
        return "glm-5.2-free"
    return "claude-sonnet-4-6"


# ── Provider mapping ───────────────────────────────────────────────────

MODEL_PROVIDER: dict[str, str] = {
    "glm-5.2-free": "zenmux",
    "gpt-4.1-mini": "openai",
    "claude-haiku-4-5-20251001": "anthropic",
    "claude-sonnet-4-6": "anthropic",
}

MODEL_DISPLAY_NAME: dict[str, str] = {
    "glm-5.2-free": "GLM-5.2 Free",
    "gpt-4.1-mini": "GPT-4.1 Mini",
    "claude-haiku-4-5-20251001": "Claude Haiku 4.5",
    "claude-sonnet-4-6": "Claude Sonnet 4.6",
}


# ── Escalation rules ───────────────────────────────────────────────────

# If alignment confidence falls below this threshold,
# the synthesis step escalates to Claude Sonnet 4.6.
ALIGNMENT_CONFIDENCE_THRESHOLD: float = 0.7

# If any individual dimension score >= 3, the task is a candidate for
# at least GPT-4.1 Mini (bypasses free tier).
CANDIDATE_ESCALATION_DIMENSION_SCORE: int = 3


def should_escalate(scores: dict[str, int], current_tier: str) -> str | None:
    """Return the escalated model ID if escalation is warranted, else None.

    Checks whether any dimension score signals a harder task than the
    current tier can handle, and returns the next appropriate tier.
    """
    total = sum(scores.values())
    if current_tier == "glm-5.2-free" and any(
        v >= CANDIDATE_ESCALATION_DIMENSION_SCORE for v in scores.values()
    ):
        return "gpt-4.1-mini"
    if current_tier == "gpt-4.1-mini" and scores.get("reasoning_type", 1) >= 2:
        return "claude-haiku-4-5-20251001"
    return None


# ── Routing decision output schema ─────────────────────────────────────

RoutingDecision = dict

ROUTING_SCHEMA_EXAMPLE: RoutingDecision = {
    "task": "string describing the task",
    "scores": {
        "data_sources": 1,
        "reasoning_type": 1,
        "output_audience": 1,
        "token_volume": 1,
        "confidence": 1,
    },
    "total_score": 5,
    "assigned_model": "model-id",
    "provider": "zenmux | openai | anthropic",
    "reasoning": "one sentence explaining why this tier was chosen",
    "escalation_condition": "what would trigger an upgrade to the next tier",
}


# ── Graph node names (shared constants) ───────────────────────────────--

class Nodes:
    ROUTER = "router"
    CALENDAR_FETCH = "calendar_fetch"
    DOCS_FETCH = "docs_fetch"
    EXTRACT_ACTION_ITEMS = "extract_action_items"
    ANALYZE_ALIGNMENT = "analyze_alignment"
    SYNTHESIS = "synthesis"
    SYNTHESIS_ESCALATED = "synthesis_escalated"
    OUTPUT = "output"
    END = "__end__"
