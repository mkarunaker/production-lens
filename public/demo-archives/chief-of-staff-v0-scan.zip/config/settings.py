"""Central configuration loaded from .env.

Loads all environment variables, validates required keys,
and provides typed access to all settings.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from dotenv import load_dotenv

load_dotenv()


class ConfigError(Exception):
    """Raised when a required configuration value is missing or invalid."""


def _require(key: str, hint: str = "") -> str:
    val = os.environ.get(key)
    if not val:
        msg = f"Missing required environment variable: {key}"
        if hint:
            msg += f"\n  {hint}"
        raise ConfigError(msg)
    return val


def _optional(key: str, default: str = "") -> str:
    return os.environ.get(key, default)


@dataclass
class Settings:
    # ── Google OAuth ───────────────────────────────────────────────────
    google_credentials_path: str = ""
    google_token_path: str = "token.pickle"

    # ── Goals Document ──────────────────────────────────────────────────
    goals_document_id: str = ""

    # ── Model API Keys ──────────────────────────────────────────────────
    zenmux_api_key: str = ""
    zenmux_base_url: str = "https://api.zenmux.com/v1"

    openai_api_key: str = ""

    anthropic_api_key: str = ""

    # ── Derived / computed ──────────────────────────────────────────────
    available_models: list[str] = field(default_factory=list)

    @classmethod
    def from_env(cls) -> "Settings":
        creds_path = _require(
            "GOOGLE_CREDENTIALS_PATH",
            "Path to the OAuth client secrets JSON downloaded from Google Cloud Console.",
        )

        goals_doc_id = _require(
            "GOALS_DOCUMENT_ID",
            "The document ID from your Google Docs URL — e.g. '1aBcDeFgHiJkLmNoPqRsTuVwXyZ'",
        )

        obj = cls(
            google_credentials_path=creds_path,
            google_token_path=_optional("GOOGLE_TOKEN_PATH", "token.pickle"),
            goals_document_id=goals_doc_id,
            zenmux_api_key=_optional("ZENMUX_API_KEY"),
            zenmux_base_url=_optional("ZENMUX_BASE_URL", "https://api.zenmux.com/v1"),
            openai_api_key=_optional("OPENAI_API_KEY"),
            anthropic_api_key=_optional("ANTHROPIC_API_KEY"),
        )

        available = []
        if obj.zenmux_api_key:
            available.append("glm-5.2-free")
        if obj.openai_api_key:
            available.append("gpt-4.1-mini")
        if obj.anthropic_api_key:
            available.append("claude-haiku-4-5-20251001")
            available.append("claude-sonnet-4-6")
        if not available:
            raise ConfigError(
                "No model API keys configured.\n"
                "  Set at least one of: ZENMUX_API_KEY, OPENAI_API_KEY, ANTHROPIC_API_KEY"
            )
        obj.available_models = available
        return obj


settings = Settings.from_env()
