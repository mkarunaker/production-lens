"""Google Calendar tool.

Fetches today's events via the Google Calendar API.
Uses OAuth 2.0 (desktop app flow) — credentials.json from Google Cloud Console.
Token is saved to token.pickle after the first authorization.
"""

from __future__ import annotations

import logging
import os
import pickle
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from langchain_core.tools import tool

from config.settings import settings

logger = logging.getLogger(__name__)

SCOPES = [
    "https://www.googleapis.com/auth/calendar.readonly",
    "https://www.googleapis.com/auth/documents.readonly",
]


def _get_credentials() -> Any:
    """Return Google API credentials via OAuth 2.0.

    First run: opens a browser for user authorization.
    Subsequent runs: reuses the saved token.pickle.
    Token auto-refreshes when expired.
    """
    from google.auth.transport.requests import Request

    creds = None
    token_path = Path(settings.google_token_path)

    # Load saved token
    if token_path.exists():
        try:
            with open(token_path, "rb") as f:
                creds = pickle.load(f)
        except Exception as exc:
            logger.warning("Failed to load token: %s", exc)

    # If no valid token, run OAuth flow
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            try:
                from google_auth_oauthlib.flow import InstalledAppFlow
            except ImportError:
                raise ImportError(
                    "Missing google-auth-oauthlib. Install with: pip install google-auth-oauthlib"
                ) from None

            flow = InstalledAppFlow.from_client_secrets_file(
                settings.google_credentials_path, SCOPES
            )
            creds = flow.run_local_server(port=0)

        # Save token for next run
        token_path.parent.mkdir(parents=True, exist_ok=True)
        with open(token_path, "wb") as f:
            pickle.dump(creds, f)
        logger.info("OAuth token saved to %s", token_path)

    return creds


def _build_service() -> Any:
    """Build and return a Google Calendar API service object."""
    try:
        from google.auth.transport.requests import Request
        from googleapiclient.discovery import build
    except ImportError:
        raise ImportError(
            "Missing google-api-python-client or google-auth.\n"
            "  Install with: pip install google-api-python-client google-auth google-auth-oauthlib"
        ) from None

    creds = _get_credentials()
    return build("calendar", "v3", credentials=creds)


@tool
def fetch_today_events(user_email: str | None = None) -> str:
    """Fetch today's calendar events.

    Returns a formatted list of events with start/end times, titles,
    and descriptions. If the calendar is empty, returns a clear message.
    """
    try:
        service = _build_service()
    except Exception as exc:
        logger.error("Failed to build Calendar service: %s", exc)
        return f"Calendar error: could not initialize Google Calendar API — {exc}"

    now = datetime.now(timezone.utc)
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    today_end = today_start + timedelta(days=1)

    try:
        events_result = (
            service.events()
            .list(
                calendarId="primary",
                timeMin=today_start.isoformat(),
                timeMax=today_end.isoformat(),
                singleEvents=True,
                orderBy="startTime",
                maxResults=50,
            )
            .execute()
        )
    except Exception as exc:
        logger.error("Calendar API call failed: %s", exc)
        return f"Calendar error: could not fetch events — {exc}"

    events = events_result.get("items", [])
    if not events:
        return "No events scheduled for today."

    lines: list[str] = []
    for ev in events:
        start = ev["start"].get("dateTime", ev["start"].get("date", "?"))
        end = ev["end"].get("dateTime", ev["end"].get("date", "?"))
        title = ev.get("summary", "(no title)")
        desc = ev.get("description", "")
        lines.append(f"- {start} → {end} | {title}")
        if desc:
            short_desc = desc[:200].replace("\n", " ")
            lines.append(f"  Notes: {short_desc}")

    return "Today's schedule:\n" + "\n".join(lines)
