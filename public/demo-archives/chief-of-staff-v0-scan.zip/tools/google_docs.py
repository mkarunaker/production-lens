"""Google Docs tool.

Reads a designated goals document by document ID via the Google Docs API.
Uses OAuth 2.0 (desktop app flow) — shares token.pickle with the Calendar tool.
"""

from __future__ import annotations

import logging
import pickle
from pathlib import Path
from typing import Any

from langchain_core.tools import tool

from config.settings import settings

logger = logging.getLogger(__name__)

SCOPES = [
    "https://www.googleapis.com/auth/calendar.readonly",
    "https://www.googleapis.com/auth/documents.readonly",
]


def _get_credentials() -> Any:
    """Return Google API credentials via OAuth 2.0.

    Reuses the same token.pickle as the Calendar tool.
    First run: opens a browser for user authorization.
    Subsequent runs: reuses the saved token.
    Token auto-refreshes when expired.
    """
    creds = None
    token_path = Path(settings.google_token_path)

    if token_path.exists():
        try:
            with open(token_path, "rb") as f:
                creds = pickle.load(f)
        except Exception as exc:
            logger.warning("Failed to load token: %s", exc)

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            from google.auth.transport.requests import Request
            creds.refresh(Request())
        else:
            try:
                from google_auth_oauthlib.flow import InstalledAppFlow
            except ImportError:
                raise ImportError(
                    "Missing google-auth-oauthlib. Install with: pip install google-auth-oauthlib"
                ) from None

            flow = InstalledAppFlow.from_client_secrets_file(
                settings.google_credentials_path, SCOPES
            )
            creds = flow.run_local_server(port=0)

        token_path.parent.mkdir(parents=True, exist_ok=True)
        with open(token_path, "wb") as f:
            pickle.dump(creds, f)
        logger.info("OAuth token saved to %s", token_path)

    return creds


def _build_service() -> Any:
    """Build and return a Google Docs API service object."""
    try:
        from google.auth.transport.requests import Request
        from googleapiclient.discovery import build
    except ImportError:
        raise ImportError(
            "Missing google-api-python-client or google-auth.\n"
            "  Install with: pip install google-api-python-client google-auth google-auth-oauthlib"
        ) from None

    creds = _get_credentials()
    return build("docs", "v1", credentials=creds)


def _extract_text(structural_elements: list[dict], indent: str = "") -> list[str]:
    """Recursively extract text from Google Docs structural elements."""
    lines: list[str] = []
    for elem in structural_elements or []:
        if "paragraph" in elem:
            para = elem["paragraph"]
            runs = []
            for run_elem in para.get("elements", []):
                if "textRun" in run_elem:
                    runs.append(run_elem["textRun"].get("content", ""))
            text = "".join(runs)
            if text.strip():
                lines.append(indent + text.rstrip("\n"))
        elif "table" in elem:
            for row in elem["table"]["tableRows"]:
                for cell in row["tableCells"]:
                    lines.extend(_extract_text(cell.get("content", []), indent + "  "))
        elif "list" in elem:
            for item in elem["list"]["listItems"]:
                lines.append(indent + "- " + item["text"])
    return lines


@tool
def fetch_goals_doc(document_id: str | None = None) -> str:
    """Read the quarterly goals document from Google Docs.

    Returns the full document content as plain text, preserving
    heading structure. The content is a candidate for prompt caching
    in downstream Anthropic model calls.
    """
    doc_id = document_id or settings.goals_document_id
    if not doc_id:
        return "No goals document configured — set GOALS_DOCUMENT_ID in .env"

    try:
        service = _build_service()
    except Exception as exc:
        logger.error("Failed to build Docs service: %s", exc)
        return f"Docs error: could not initialize Google Docs API — {exc}"

    try:
        doc = service.documents().get(documentId=doc_id).execute()
    except Exception as exc:
        logger.error("Docs API call failed: %s", exc)
        return f"Docs error: could not fetch document — {exc}"

    title = doc.get("title", "Untitled")
    body = doc.get("body", {})
    content_lines = _extract_text(body.get("content", []))

    if not content_lines:
        return f"Document '{title}' appears to be empty."

    header = f"# {title}\n\n"
    return header + "\n".join(content_lines)
