# Chief of Staff AI Agent

A multi-model, multi-agent system that helps leaders align their daily work with quarterly goals. Built with LangGraph and powered by a dynamic model ladder (GLM-5.2 Free → GPT-4.1 Mini → Claude Haiku 4.5 → Claude Sonnet 4.6).

## Architecture

```
                          ┌─────────────────────────┐
                          │    Router Agent          │
                          │  (scores task at runtime) │
                          └──────────┬──────────────┘
                                     │
     ┌───────────────────────────────┼───────────────────────────────┐
     │                               │                               │
     ▼                               ▼                               ▼
┌─────────────┐            ┌──────────────────┐          ┌──────────────────┐
│ GLM-5.2 Free │            │   GPT-4.1 Mini    │          │  Claude Haiku    │
│ (fetch, parse)│            │ (extraction, light)│          │  (goal reasoning) │
└─────────────┘            └──────────────────┘          └──────────────────┘
                                                                    │
                                                          ┌─────────▼─────────┐
                                                          │ Claude Sonnet 4.6  │
                                                          │ (escalation only)   │
                                                          └───────────────────┘
```

The Orchestrator Agent runs as a LangGraph graph:

```
START → router → calendar_fetch → docs_fetch → extract_action_items
  → analyze_alignment ──┬── (confidence ≥ 0.7) → synthesis → output → END
                         └── (confidence < 0.7) → synthesis_escalated (Sonnet 4.6) → END
```

## Prerequisites

- **Python 3.11+**
- **Google Cloud Project** with Calendar API and Docs API enabled
- **Google Service Account** with domain-wide delegation
- **At least one model API key** (ZenMux, OpenAI, or Anthropic)

## Setup

### 1. Google Cloud Configuration

1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. Create a project (or select existing)
3. Enable **Google Calendar API** and **Google Docs API**
4. Go to **IAM & Admin → Service Accounts** → Create Service Account
5. Download the JSON key
6. Enable **Domain-Wide Delegation** for the service account
7. In Google Workspace Admin Console, grant the service account access to:
   - `https://www.googleapis.com/auth/calendar.readonly`
   - `https://www.googleapis.com/auth/documents.readonly`

### 2. Environment Variables

```bash
cp .env.example .env
```

Edit `.env` and fill in:
- `GOOGLE_SERVICE_ACCOUNT_JSON` — paste the full JSON key
- `GOOGLE_ADMIN_EMAIL` — your Google Workspace admin email
- `GOALS_DOCUMENT_ID` — the ID from your goals doc URL
- At least one model API key (ZenMux, OpenAI, or Anthropic)

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

### 4. Run the Server

```bash
uvicorn api.main:app --host 0.0.0.0 --port 8080 --reload
```

Open `http://localhost:8080/frontend/index.html` for the dashboard,
or call `curl http://localhost:8080/brief` for the JSON API.

## Project Structure

```
├── agents/
│   ├── orchestrator.py      # LangGraph graph with conditional escalation
│   └── router.py            # Model routing by task complexity
├── api/
│   └── main.py              # FastAPI app with /brief endpoint
├── config/
│   └── settings.py          # Central config loaded from .env
├── frontend/
│   └── index.html           # Morning brief dashboard UI
├── models/
│   ├── clients.py           # Model client init with graceful degradation
│   └── router_config.py     # Scoring dimensions, thresholds, rules
├── tools/
│   ├── google_calendar.py   # Fetch today's events (modular auth)
│   └── google_docs.py       # Read goals doc (modular auth)
├── .env.example
├── requirements.txt
└── README.md
```

## Model Ladder

| Tier | Model | Provider | Use Case |
|------|-------|----------|----------|
| Free | GLM-5.2 Free | ZenMux | Fetching, parsing, structured extraction |
| Light | GPT-4.1 Mini | OpenAI | Summarization, action item extraction |
| Goal Reasoning | Claude Haiku 4.5 | Anthropic | Goal alignment analysis |
| Escalation | Claude Sonnet 4.6 | Anthropic | Complex insights, low-confidence re-runs |

The Router Agent scores each task at runtime on 5 dimensions and assigns the appropriate tier. If alignment confidence falls below 0.7, the synthesis step escalates to Sonnet 4.6.

## Adding New Integrations

Each integration (Notion, email, etc.) follows the same pattern:

1. Create a new file in `/tools/` with a `_get_credentials()` function for auth
2. Create a LangChain `@tool` decorated function
3. Add the tool to the orchestrator graph in `/agents/orchestrator.py`

Auth is modular — replace `_get_credentials()` in any tool file to switch from service account to OAuth without touching the rest of the code.
