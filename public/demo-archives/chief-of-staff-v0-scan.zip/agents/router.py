"""Router Agent.

Evaluates tasks at runtime across five scoring dimensions,
assigns a model tier, and outputs a structured routing decision.
Logs every decision for visibility in the dashboard UI.
"""

from __future__ import annotations

import logging
from typing import Any

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_core.output_parsers import PydanticOutputParser
from langchain_core.prompts import ChatPromptTemplate
from pydantic import BaseModel, Field

from models.clients import _AVAILABLE, get_client
from models.router_config import (
    MODEL_DISPLAY_NAME,
    MODEL_PROVIDER,
    resolve_tier,
    should_escalate,
)

logger = logging.getLogger(__name__)


# ── Structured output schema ─────────────────────────────────────────

class RoutingScores(BaseModel):
    data_sources: int = Field(
        ge=1, le=3,
        description="1=one source, 2=two sources, 3=three or more",
    )
    reasoning_type: int = Field(
        ge=1, le=3,
        description="1=extraction/formatting, 2=summarization, 3=judgment/nuance",
    )
    output_audience: int = Field(
        ge=1, le=3,
        description="1=another agent, 2=structured data, 3=human-facing",
    )
    token_volume: int = Field(
        ge=1, le=3,
        description="1=under 2K, 2=2K-10K, 3=over 10K",
    )
    confidence: int = Field(
        ge=1, le=3,
        description="1=high confidence, 2=moderate, 3=low confidence",
    )


class RoutingDecision(BaseModel):
    task: str = Field(description="String describing the task")
    scores: RoutingScores
    total_score: int = Field(ge=5, le=15)
    assigned_model: str = Field(description="Model ID assigned to this task")
    provider: str = Field(description="zenmux | openai | anthropic")
    reasoning: str = Field(description="One sentence explaining why this tier was chosen")
    escalation_condition: str = Field(
        description="What would trigger an upgrade to the next tier",
    )


# ── Router prompt ─────────────────────────────────────────────────────

ROUTER_SYSTEM_PROMPT = """\
You are a routing agent that evaluates tasks and assigns them to the \
appropriate AI model tier based on complexity.

Score the task on these five dimensions (each 1-3):
- data_sources: How many data sources must be cross-referenced?
  1 = one source, 2 = two sources, 3 = three or more
- reasoning_type: What kind of reasoning is needed?
  1 = extraction / formatting / parsing,
  2 = summarization / single-source analysis,
  3 = judgment / nuance / pattern detection
- output_audience: Who is the output for?
  1 = another agent (structured intermediate),
  2 = structured data / JSON,
  3 = human-facing final output
- token_volume: Estimated tokens for input + output?
  1 = under 2K, 2 = 2K-10K, 3 = over 10K
- confidence: How confident are we in the available context?
  1 = high (well-defined, complete context),
  2 = moderate (some ambiguity),
  3 = low (uncertain, needs escalation)

Routing thresholds (total score):
- 5-7  → Free Tier (GLM-5.2 Free)
- 8-10 → Light (GPT-4.1 Mini)
- 11-13 → Goal Reasoning (Claude Haiku 4.5)
- 14-15 → Escalation (Claude Sonnet 4.6)

Return a structured routing decision with scores and the assigned model.
"""


# ── Router logic ──────────────────────────────────────────────────────

def _preferred_router_model() -> str:
    """Return the cheapest available model for routing decisions."""
    for preferred in ("claude-haiku-4-5-20251001", "claude-sonnet-4-6", "gpt-4.1-mini"):
        if preferred in _AVAILABLE:
            return preferred
    # fall back to whatever is available
    if _AVAILABLE:
        return next(iter(_AVAILABLE))
    raise RuntimeError("No model clients available for routing")


def route_task(task_description: str, context: dict[str, Any] | None = None) -> RoutingDecision:
    """Score a task and return a structured routing decision.

    Args:
        task_description: A string describing the task to route.
        context: Optional context about prior steps (scores, confidence, etc.).

    Returns:
        A RoutingDecision with scores, assigned model, and escalation condition.
    """
    model_id = _preferred_router_model()
    client_wrapper = get_client(model_id)
    llm = client_wrapper.client

    parser = PydanticOutputParser(pydantic_object=RoutingDecision)

    prompt = ChatPromptTemplate.from_messages([
        ("system", ROUTER_SYSTEM_PROMPT),
        ("human", "Task to route:\n{task}\n\n{format_instructions}"),
    ])

    chain = prompt | llm | parser

    try:
        decision = chain.invoke({
            "task": task_description,
            "format_instructions": parser.get_format_instructions(),
        })
    except Exception as exc:
        logger.warning("LLM routing failed (%s), using fallback scoring", exc)
        decision = _fallback_route(task_description, context)

    return decision


def _fallback_route(
    task_description: str,
    context: dict[str, Any] | None = None,
) -> RoutingDecision:
    """Heuristic fallback when the LLM router is unavailable.

    Uses simple keyword and context-based rules to assign a tier.
    """
    desc_lower = task_description.lower()
    ctx = context or {}

    if any(kw in desc_lower for kw in ("escalate", "complex", "synthesis", "insight")):
        base = "claude-sonnet-4-6"
        total = 14
    elif any(kw in desc_lower for kw in ("align", "analyze", "cross-reference", "goal")):
        base = "claude-haiku-4-5-20251001"
        total = 11
    elif any(kw in desc_lower for kw in ("extract", "parse", "action item", "summarize")):
        base = "gpt-4.1-mini"
        total = 8
    else:
        base = "glm-5.2-free"
        total = 5

    # If the chosen model isn't available, fall back down the ladder
    for candidate in [base, "gpt-4.1-mini", "glm-5.2-free"]:
        if candidate in _AVAILABLE:
            chosen = candidate
            break
    else:
        chosen = next(iter(_AVAILABLE)) if _AVAILABLE else "glm-5.2-free"

    return RoutingDecision(
        task=task_description,
        scores={
            "data_sources": 2 if "cross" in desc_lower or "and" in desc_lower else 1,
            "reasoning_type": 3 if "analyze" in desc_lower or "insight" in desc_lower else 2,
            "output_audience": 2,
            "token_volume": 2,
            "confidence": 2,
        },
        total_score=total,
        assigned_model=chosen,
        provider=MODEL_PROVIDER.get(chosen, "unknown"),
        reasoning=f"Fallback routing based on keywords in task: {task_description[:60]}",
        escalation_condition="Alignment confidence < 0.7 triggers upgrade to next tier",
    )


def format_routing_log(decision: RoutingDecision) -> dict:
    """Format a routing decision as a human-readable log entry."""
    return {
        "task": decision.task,
        "scores": decision.scores.model_dump(),
        "total_score": decision.total_score,
        "assigned_model": MODEL_DISPLAY_NAME.get(
            decision.assigned_model, decision.assigned_model
        ),
        "provider": decision.provider,
        "reasoning": decision.reasoning,
        "escalation_condition": decision.escalation_condition,
    }
