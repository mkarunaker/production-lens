"""Orchestrator Agent.

LangGraph graph that builds a morning brief:
  - Fetches today's calendar events
  - Reads the quarterly goals doc
  - Extracts action items from calendar events
  - Analyzes goal alignment
  - Synthesizes the morning brief
  - Outputs alignment flag: On Track / Needs Attention / Misaligned

Conditional edge: escalates synthesis to Sonnet 4.6 if alignment confidence < 0.7.
"""

from __future__ import annotations

import logging
from typing import Annotated, Any, Literal, TypedDict

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langgraph.graph import END, START, StateGraph
from langgraph.graph.state import CompiledStateGraph

from agents.router import (
    RoutingDecision,
    _fallback_route,
    format_routing_log,
    route_task,
)
from models.clients import _AVAILABLE, get_client
from models.router_config import (
    ALIGNMENT_CONFIDENCE_THRESHOLD,
    MODEL_DISPLAY_NAME,
    MODEL_PROVIDER,
    Nodes,
)
from tools.google_calendar import fetch_today_events
from tools.google_docs import fetch_goals_doc

logger = logging.getLogger(__name__)


# ── Graph state ───────────────────────────────────────────────────────

class AgentState(TypedDict):
    messages: Annotated[list, "Message list for LangGraph"]
    task_description: str
    calendar_events: str
    goals_doc_content: str
    action_items: str
    alignment_result: str
    alignment_flag: str
    alignment_confidence: float
    morning_brief: str
    routing_log: list[dict]
    error: str


# ── Router node ───────────────────────────────────────────────────────

def router_node(state: AgentState) -> dict:
    """Evaluate the overall task and assign models to each step."""
    task = state.get("task_description", "Generate a morning brief")

    try:
        decision = route_task(task)
    except Exception as exc:
        logger.warning("Router LLM failed (%s), using fallback", exc)
        decision = _fallback_route(task)

    routing_log = [format_routing_log(decision)]

    return {
        "routing_log": routing_log,
        "messages": [HumanMessage(content=f"Routing decision: {decision.assigned_model}")],
    }


# ── Tool nodes ────────────────────────────────────────────────────────

def calendar_fetch_node(state: AgentState) -> dict:
    """Fetch today's calendar events."""
    decision = _route_for_step("Fetch today's calendar events")
    log_entry = format_routing_log(decision)
    logger.info("Calendar fetch routed to %s", decision.assigned_model)

    try:
        result = fetch_today_events.invoke({})
    except Exception as exc:
        logger.error("Calendar fetch failed: %s", exc)
        return {
            "calendar_events": f"Error fetching calendar: {exc}",
            "error": str(exc),
            "routing_log": state["routing_log"] + [log_entry],
        }

    return {
        "calendar_events": result,
        "routing_log": state["routing_log"] + [log_entry],
    }


def docs_fetch_node(state: AgentState) -> dict:
    """Read the quarterly goals document."""
    decision = _route_for_step("Read the quarterly goals document")
    log_entry = format_routing_log(decision)
    logger.info("Docs fetch routed to %s", decision.assigned_model)

    try:
        result = fetch_goals_doc.invoke({})
    except Exception as exc:
        logger.error("Docs fetch failed: %s", exc)
        return {
            "goals_doc_content": f"Error fetching goals doc: {exc}",
            "error": str(exc),
            "routing_log": state["routing_log"] + [log_entry],
        }

    return {
        "goals_doc_content": result,
        "routing_log": state["routing_log"] + [log_entry],
    }


# ── LLM-powered nodes ─────────────────────────────────────────────────

EXTRACT_SYSTEM_PROMPT = """\
You are an action-item extraction specialist. Given a list of today's \
calendar events, extract discrete action items, decisions, and follow-ups \
implied by each event's title and description.

Return a concise bullet list of action items. If an event has no clear \
action items, note it as "No action items extracted" for that event.
"""


def extraction_node(state: AgentState) -> dict:
    """Extract action items from calendar events using assigned model."""
    decision = _route_for_step(
        "Extract action items from calendar events for the morning brief"
    )
    log_entry = format_routing_log(decision)
    logger.info("Extraction routed to %s", decision.assigned_model)

    model_id = decision.assigned_model
    if model_id not in _AVAILABLE:
        model_id = _fallback_model(model_id)
        logger.info("Extraction fell back to %s", model_id)

    client = get_client(model_id).client
    prompt = ChatPromptTemplate.from_messages([
        ("system", EXTRACT_SYSTEM_PROMPT),
        ("human", "Today's calendar events:\n\n{events}"),
    ])
    chain = prompt | client | StrOutputParser()

    try:
        result = chain.invoke({"events": state.get("calendar_events", "No events available")})
    except Exception as exc:
        logger.error("Extraction failed: %s", exc)
        result = f"Error extracting action items: {exc}"

    return {
        "action_items": result,
        "routing_log": state["routing_log"] + [log_entry],
    }


ALIGNMENT_SYSTEM_PROMPT = """\
You are a goal-alignment analyst. Compare a leader's daily schedule and \
action items against their quarterly goals. Determine whether today's \
work is advancing the goals.

Output:
- alignment_flag: "On Track" | "Needs Attention" | "Misaligned"
- confidence: a float between 0.0 and 1.0 indicating how confident you \
  are in the assessment
- reasoning: 2-3 sentences explaining the alignment assessment

Be honest — it's better to flag "Needs Attention" than to give false \
positive feedback.
"""

ALIGNMENT_HUMAN_TEMPLATE = """\
Quarterly Goals:
{goals}

Today's Calendar Events:
{events}

Action Items:
{action_items}
"""


def alignment_node(state: AgentState) -> dict:
    """Cross-reference calendar events vs goals and assess alignment."""
    decision = _route_for_step(
        "Analyze goal alignment — cross-reference events vs quarterly goals"
    )
    log_entry = format_routing_log(decision)
    logger.info("Alignment analysis routed to %s", decision.assigned_model)

    model_id = decision.assigned_model
    if model_id not in _AVAILABLE:
        model_id = _fallback_model(model_id)

    client = get_client(model_id).client
    prompt = ChatPromptTemplate.from_messages([
        ("system", ALIGNMENT_SYSTEM_PROMPT),
        ("human", ALIGNMENT_HUMAN_TEMPLATE),
    ])
    chain = prompt | client | StrOutputParser()

    try:
        result = chain.invoke({
            "goals": state.get("goals_doc_content", "No goals available"),
            "events": state.get("calendar_events", "No events available"),
            "action_items": state.get("action_items", "No action items available"),
        })
    except Exception as exc:
        logger.error("Alignment analysis failed: %s", exc)
        return {
            "alignment_result": f"Error in alignment analysis: {exc}",
            "alignment_flag": "Needs Attention",
            "alignment_confidence": 0.0,
            "routing_log": state["routing_log"] + [log_entry],
        }

    # Parse alignment flag and confidence from the output
    flag, confidence = _parse_alignment_output(result)

    return {
        "alignment_result": result,
        "alignment_flag": flag,
        "alignment_confidence": confidence,
        "routing_log": state["routing_log"] + [log_entry],
    }


def _parse_alignment_output(output: str) -> tuple[str, float]:
    """Extract alignment_flag and confidence from LLM output."""
    flag = "Needs Attention"
    confidence = 0.5

    lines = output.lower().split("\n")
    for line in lines:
        if "alignment_flag" in line or "flag" in line:
            if "on track" in line:
                flag = "On Track"
            elif "misaligned" in line:
                flag = "Misaligned"
            else:
                flag = "Needs Attention"
        if "confidence" in line:
            import re
            match = re.search(r"([0-9]*\.?[0-9]+)", line)
            if match:
                confidence = float(match.group(1))

    return flag, min(max(confidence, 0.0), 1.0)


SYNTHESIS_SYSTEM_PROMPT = """\
You are a Chief of Staff AI. Synthesize the following data into a clear, \
actionable morning brief for a leader.

Include:
1. A one-paragraph summary of today's schedule
2. Key action items extracted from events
3. Goal alignment assessment — is today's work aligned with quarterly goals?
4. A clear alignment flag at the top: 🟢 On Track / 🟡 Needs Attention / 🔴 Misaligned

Be concise and direct. This is for a busy leader who needs the signal fast.
"""

SYNTHESIS_HUMAN_TEMPLATE = """\
Today's Calendar Events:
{events}

Action Items:
{action_items}

Goal Alignment Assessment:
{alignment}

Quarterly Goals:
{goals}
"""


def synthesis_node(state: AgentState) -> dict:
    """Generate the morning brief.

    If alignment confidence < threshold, escalate to Sonnet 4.6.
    """
    confidence = state.get("alignment_confidence", 0.5)
    needs_escalation = confidence < ALIGNMENT_CONFIDENCE_THRESHOLD

    if needs_escalation:
        model_id = "claude-sonnet-4-6"
        log_reasoning = "Alignment confidence below threshold — escalated to Sonnet 4.6"
    else:
        decision = _route_for_step(
            "Synthesize morning brief from calendar, goals, and alignment data"
        )
        model_id = decision.assigned_model
        log_reasoning = decision.reasoning

    if model_id not in _AVAILABLE:
        model_id = _fallback_model(model_id)

    log_entry = {
        "task": "Synthesize morning brief",
        "scores": {
            "data_sources": 3,
            "reasoning_type": 3,
            "output_audience": 3,
            "token_volume": 2,
            "confidence": 2 if not needs_escalation else 1,
        },
        "total_score": 999,
        "assigned_model": MODEL_DISPLAY_NAME.get(model_id, model_id),
        "provider": MODEL_PROVIDER.get(model_id, "unknown"),
        "reasoning": log_reasoning,
        "escalation_condition": "N/A (final step)",
    }
    logger.info("Synthesis routed to %s (escalated=%s)", model_id, needs_escalation)

    client = get_client(model_id).client
    prompt = ChatPromptTemplate.from_messages([
        ("system", SYNTHESIS_SYSTEM_PROMPT),
        ("human", SYNTHESIS_HUMAN_TEMPLATE),
    ])
    chain = prompt | client | StrOutputParser()

    try:
        brief = chain.invoke({
            "events": state.get("calendar_events", "No events"),
            "action_items": state.get("action_items", "No action items"),
            "alignment": state.get("alignment_result", "No alignment data"),
            "goals": state.get("goals_doc_content", "No goals data"),
        })
    except Exception as exc:
        logger.error("Synthesis failed: %s", exc)
        brief = f"Error generating morning brief: {exc}"

    return {
        "morning_brief": brief,
        "routing_log": state["routing_log"] + [log_entry],
    }


def output_node(state: AgentState) -> dict:
    """Format and return the final result."""
    return {
        "messages": [
            HumanMessage(content=state.get("morning_brief", "No brief generated"))
        ],
    }


# ── Helpers ───────────────────────────────────────────────────────────

def _route_for_step(task: str) -> RoutingDecision:
    """Route a single step. Falls back to heuristic if LLM routing fails."""
    try:
        return route_task(task)
    except Exception as exc:
        logger.warning("Step routing failed (%s), using fallback", exc)
        return _fallback_route(task)


def _fallback_model(preferred: str) -> str:
    """Fall back to the next available model if the preferred one is missing."""
    for candidate in ("gpt-4.1-mini", "glm-5.2-free"):
        if candidate in _AVAILABLE:
            return candidate
    return next(iter(_AVAILABLE)) if _AVAILABLE else "gpt-4.1-mini"


# ── Conditional edge ──────────────────────────────────────────────────

def should_escalate_synthesis(state: AgentState) -> Literal["synthesis", "synthesis_escalated"]:
    """Decide whether to use the escalated synthesis path."""
    if state.get("alignment_confidence", 0.5) < ALIGNMENT_CONFIDENCE_THRESHOLD:
        return "synthesis_escalated"
    return "synthesis"


# ── Build graph ───────────────────────────────────────────────────────

def build_graph() -> CompiledStateGraph:
    """Construct and compile the morning brief LangGraph."""

    workflow = StateGraph(AgentState)

    # Add nodes
    workflow.add_node(Nodes.ROUTER, router_node)
    workflow.add_node(Nodes.CALENDAR_FETCH, calendar_fetch_node)
    workflow.add_node(Nodes.DOCS_FETCH, docs_fetch_node)
    workflow.add_node(Nodes.EXTRACT_ACTION_ITEMS, extraction_node)
    workflow.add_node(Nodes.ANALYZE_ALIGNMENT, alignment_node)
    workflow.add_node(Nodes.SYNTHESIS, synthesis_node)
    workflow.add_node(Nodes.SYNTHESIS_ESCALATED, synthesis_node)
    workflow.add_node(Nodes.OUTPUT, output_node)

    # Edges
    workflow.add_edge(START, Nodes.ROUTER)
    workflow.add_edge(Nodes.ROUTER, Nodes.CALENDAR_FETCH)
    workflow.add_edge(Nodes.CALENDAR_FETCH, Nodes.DOCS_FETCH)
    workflow.add_edge(Nodes.DOCS_FETCH, Nodes.EXTRACT_ACTION_ITEMS)
    workflow.add_edge(Nodes.EXTRACT_ACTION_ITEMS, Nodes.ANALYZE_ALIGNMENT)
    workflow.add_conditional_edges(
        Nodes.ANALYZE_ALIGNMENT,
        should_escalate_synthesis,
        {
            "synthesis": Nodes.SYNTHESIS,
            "synthesis_escalated": Nodes.SYNTHESIS_ESCALATED,
        },
    )
    workflow.add_edge(Nodes.SYNTHESIS, Nodes.OUTPUT)
    workflow.add_edge(Nodes.SYNTHESIS_ESCALATED, Nodes.OUTPUT)
    workflow.add_edge(Nodes.OUTPUT, END)

    return workflow.compile()


# ── Convenience runner ────────────────────────────────────────────────

def run_morning_brief(task: str | None = None) -> dict[str, Any]:
    """Run the full morning brief pipeline and return the result."""
    graph = build_graph()
    initial_state: AgentState = {
        "messages": [],
        "task_description": task or "Generate a morning brief",
        "calendar_events": "",
        "goals_doc_content": "",
        "action_items": "",
        "alignment_result": "",
        "alignment_flag": "",
        "alignment_confidence": 0.0,
        "morning_brief": "",
        "routing_log": [],
        "error": "",
    }
    result = graph.invoke(initial_state)
    return result
